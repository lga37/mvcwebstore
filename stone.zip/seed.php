<?php 

require 'MVC/Model/BD.php';
require 'MVC/Model/Model.php';

# a partir do mysql5.7 tem que criar usuario add
$user = <<<USER 
CREATE USER 'web'@'localhost' IDENTIFIED BY '123';
GRANT SELECT,INSERT,UPDATE,DELETE ON *.* TO 'web'@'localhost';
FLUSH PRIVILEGES;

USER;


$categs = <<<CATEGS
CREATE IF NOT EXISTS TABLE 


CATEGS;

$prods = <<<PRODS



PRODS;

$clientes = <<<CLIENTES

CLIENTES;


function addCategs(int $qtd=10){

}

function addProds(int $qtd=100){
	
}

function addClientes(int $qtd=20){
	
}

function add(string $tabela, array $post): void{
	$m = new Model();
	$m->setTable($tabela);

	$m->add($post);

}


function seed(){
	addCategs();
	addProds();
	addClientes();
}

seed();