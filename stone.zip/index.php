<?php
declare(strict_types=1);
require 'MVC/Bootstrap.php';

MVC\Bootstrap::run();

