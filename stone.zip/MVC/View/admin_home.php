<br>
<div class="row">
    <div class="col-md-12">
        <div class="card card-image" style="background-image: url(https://mdbootstrap.com/img/Photos/Others/gradient1.jpg);">
            <div class="text-white text-center py-5 px-4 my-5">
                <div>
                    <h1 class="card-title pt-3 mb-5 font-bold"><strong>Area Admin</strong></h1>
                    <p class="mx-5 mb-5">
                        Bem Vindos<br><br>
                        Aqui voce podera editar :.<br>
                        
                            Categorias<br>
                            Produtos<br>
                            Clientes<br>
                            Pedidos<br>

                       

                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<br>