<form method="POST" action="<?=URL.'?c=cliente&a=login_index'?>">
    <fieldset>
        <legend>Clientes Ja Cadastrados (a@a.com 123)</legend>

        <div class="md-form">
            <i class="fa fa-at prefix"></i>
            <input type="text" id="email" name="email" class="form-control validate">
            <label for="email" data-error="wrong" data-success="ok">Email</label>
        </div>

        <div class="md-form">
            <i class="fa fa-lock prefix"></i>
            <input type="password" id="senha" name="senha" class="form-control validate">
            <label for="senha" data-error="wrong" data-success="ok">Senha</label>
        </div>

       <button class="btn btn-lg btn-block btn-outline-success">LOGIN</button>
       <br>
    </fieldset>    
</form>
<hr>
<form method="POST" action="<?=URL.'?c=cliente&a=cadastro_index'?>">
    <fieldset>
        <legend>Clientes Nao Cadastrados</legend>

        <div class="md-form">
            <i class="fa fa-user prefix"></i>
            <input type="text" id="inputNome" name="nome" class="form-control validate">
            <label for="inputNome" data-error="wrong" data-success="ok">Nome</label>
        </div>

        <div class="md-form">
            <i class="fa fa-at prefix"></i>
            <input type="text" id="inputEmail" name="email" class="form-control validate">
            <label for="inputEmail" data-error="wrong" data-success="ok">Email</label>
        </div>

        <div class="md-form">
            <i class="fa fa-lock prefix"></i>
            <input type="password" id="inputSenha" name="senha" class="form-control validate">
            <label for="inputSenha" data-error="wrong" data-success="ok">Senha</label>
        </div>

        <div class="md-form">
            <i class="fa fa-map-marker prefix"></i>
            <input type="text" id="inputCep" name="cep" class="form-control validate">
            <label for="inputCep" data-error="wrong" data-success="ok">CEP (autocomplete)</label>
        </div>

        <div class="md-form">
            <i class="fa fa-map-marker prefix"></i>
            <input type="text" id="inputEnd" name="endereco" class="form-control validate">
            <label for="inputEnd" data-error="wrong" data-success="ok">Endereco</label>
        </div>


       <button class="btn btn-lg btn-block btn-outline-info">CADASTRAR</button>
       <br>
    </fieldset>    
</form>

<script type="text/javascript">

$(document).ready(function() {

    $('#inputCep').on('keyup', '[name="cep"]', function() {
        var cep = $(this).val();
        if(cep.length == 8){
            $.getJSON("//viacep.com.br/ws/"+ cep +"/json/?callback=?", function(data) {
                if (!("erro" in data)) {
                    $('input[name="endereco"]').val(data.logradouro +'-'+data.localidade+'-'+data.uf;
                } else {
                    alert('Erro em ajax');
                }
            });    
        }
    });

});


</script>